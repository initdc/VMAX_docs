Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements. The ASF licenses this
file to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.   


## Known Bugs ##

None confirmed
One report of crashes (not consistent afaik) with motion blur and average distance mode on
Few random crashes while testing, non reproducable and unconfirmed if they are related to metaballs at all.

## TODO ##

-> 1.13 workarounds should be removed and the core problem be fixed. Oleg Bayborodin from Orbaz is looking into this if the problem is in PFlow.
	- Velocity threshold paramter is not really usefull for any other purpose
	- Using velocity given by pflow is inaccurate, measuring two positions is more accurate and reliable	
-> Additional BVH optimization: Instead of intersecting BVH at once to the leaves, it could only intersect the nearest branches and leaves first
	and then as it raymarches through the volumes it would intersect deeper into the branches. This would mean less boxes to intersect in most cases.
	Whats the benefit? More if clauses vs. less box intersections.

## Version History ##

1.14
	Feature: Motion blur can be disabled by setting samples to 1, removed alternative pflow reading method
	Feature: Colors support, Vertex Colors and pflow Vector channel can be used to give color to individual metaballs
	Feature: BerconMetaballTex, to render metaball colors
	Feature: Color fallof function
1.13 (only beta was ever released)
	Feature: Velocity Threshold to cuttoff/ignore particles traveling above given velocity
	Feature: Setting MB samples parameter to 1 uses PFlow velocity channel to get particle velocities, instead of measuring position twice
1.12
	Feature: When using a mesh as a source object and Use Particle Size is checked it takes account soft selection (0..1) multiplied by Radius
	Bug fix: Using a mesh as a source object with motion blur on doesn't crash any more
1.11
	Feature: Added some new optimizations to make things slightly faster, most noticable on high (over one million) particle counts
	Feature: Simple particle systems are supported again
	Bug fix: Texture in Multiply mode now supports Strength values above 1.0
	Bug fix: When "Use Particle Size" is on, the Leaf Size is ignored, there is no point using it with varying particle sizes
1.1
	Bug fix: Particle motion blur is now correctly computed even for particles which don't have speed but still move (locked to object surface etc.)
	Feature: Variable radius for each particle, this also means if you animate the radius it creates correct motion blur
	Feature: Any number of motion blur steps	
	Feature: Support for pflow where particle count change between frames
	Feature: Support for multiplying/subtracting the density field with a texture
	Feature: Support for clamping density field before applying texture to it
1.0 
	Released
