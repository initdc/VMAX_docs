//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by berconMetaball.rc
//
#define IDS_PARAMS                      4
#define IDS_TEXMAP                      5
#define IDS_SIZE                        6
#define IDS_MBSAMPLES                   7
#define IDS_RENDER                      8
#define IDS_VIEWPORT                    9
#define IDS_COARSENESS                  10
#define IDS_USESCALE                    11
#define IDS_TEXPARAM                    12
#define IDS_USETEXTURE                  13
#define IDS_TEXTURETYPE                 14
#define IDS_PFPARAM                     15
#define IDS_USEALLPFEVENTS              16
#define IDS_PFEVENTLIST                 17
#define IDS_ADDEVENTS                   18
#define IDS_OFFINVIEW                   19
#define IDS_ADD                         20
#define IDS_REMOVE_NODE                 21
#define IDS_REMOVE                      22
#define IDS_USECLAMP                    23
#define IDS_TEXTURESTR                  24
#define IDS_NODES                       25
#define IDS_ICON                        26
#define IDS_THRES                       27
#define IDS_STEP                        28
#define IDS_ERROR                       29
#define IDS_FIELDFUNCTION               30
#define IDS_AVERAGE                     31
#define IDS_CUTOFF                      32
#define IDS_TRIM                        33
#define IDS_DEPTH                       34
#define IDS_LENGTH                      35
#define IDS_LEAF                        36
#define IDS_NODEPARAMS                  37
#define IDS_VELOCITYTHRESH              38
#define IDS_FIELD_NONE                  39
#define IDS_FIELD_WYVILL                40
#define IDS_FIELD_SAME                  41
#define IDS_CLAMPTO                     42
#define IDS_MULTIPLY                    43
#define IDS_SUBTRACT                    44
#define IDS_FIELD_POWER2                45
#define IDS_FIELD_HERMIT2               46
#define IDS_FIELD_HERMIT4               47
#define IDD_PFLOW                       102
#define IDD_PANEL                       103
#define IDS_FIELD_POWER3                106
#define IDS_FIELD_POWER4                107
#define IDS_FIELD_POWER5                108
#define IDS_ABOUT                       109
#define IDD_ADD_DIALOG                  209
#define IDD_NODES                       210
#define IDD_ABOUT                       211
#define IDD_TEXTURE                     212
#define IDC_ADDPF_EVENT_BUTTON          1001
#define IDC_USEALLPF                    1002
#define IDC_FIELDFUNCTION               1002
#define IDC_PFLIST                      1003
#define IDC_USETEXTURE                  1003
#define IDC_FIELDFUNCTION2              1003
#define IDC_PFREMOVE                    1004
#define IDC_TEXMODE                     1004
#define IDC_SIZE_EDIT                   1012
#define IDC_SIZE_SPIN                   1013
#define IDC_THRES_EDIT                  1014
#define IDC_THRES_SPIN                  1015
#define IDC_STEP_EDIT                   1016
#define IDC_STEP_SPIN                   1017
#define IDC_ERROR_EDIT                  1018
#define IDC_ERROR_SPIN                  1019
#define IDC_CUTOFF_EDIT                 1020
#define IDC_CUTOFF_SPIN                 1021
#define IDC_TRIM_EDIT                   1022
#define IDC_TRIM_SPIN                   1023
#define IDC_DEPTH_EDIT                  1028
#define IDC_DEPTH_SPIN                  1029
#define IDC_LENGTH_EDIT                 1030
#define IDC_LENGTH_SPIN                 1031
#define IDC_LEAF_EDIT                   1032
#define IDC_LEAF_SPIN                   1033
#define IDC_ICON_EDIT                   1034
#define IDC_ICON_SPIN                   1035
#define IDC_TEXMAP                      1036
#define IDC_VEL_EDIT                    1036
#define IDC_MBSAMPLES_EDIT              1037
#define IDC_MBSAMPLES_SPIN              1038
#define IDC_CLAMP_EDIT                  1039
#define IDC_VEL_SPIN                    1039
#define IDC_CLAMP_SPIN                  1040
#define IDC_TEXSTR_EDIT                 1041
#define IDC_TEXSTR_SPIN                 1042
#define IDC_AVERAGE                     1123
#define IDC_USESCALE                    1124
#define IDC_CLAMP                       1125
#define IDC_EVENTLIST                   1265
#define IDC_ADD                         1332
#define IDC_REMOVE                      1333
#define IDC_PICK                        1334
#define IDC_NODES                       1336

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
