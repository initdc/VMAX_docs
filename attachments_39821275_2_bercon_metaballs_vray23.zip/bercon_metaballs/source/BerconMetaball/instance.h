/*
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements. The ASF licenses this
file to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.   
*/

#pragma once

#ifndef __INSTANCE_H__
#define __INSTANCE_H__

#include "Max.h"
#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"

#include "particle.h"
#include "Simpobj.h"
#include "splshape.h"

#include "meshadj.h"
#include "XTCObject.h"

#include "macrorec.h"

#include "maxobject.h"
//#include "primitive.h"
#include "primitiveStatic.h"
#include "primitiveMoving.h"

class BerconMetaballInstance:
	public VR::ShadeData,
	public VR::ShadeInstance
{
public:
	int dynamicType; // Tells if instance is static 0 or moving 1
};

#endif