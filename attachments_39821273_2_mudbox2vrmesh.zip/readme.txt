Mudbox2vrmesh
=============

This plugin for Mudbox allows the export of objects from inside Mudbox directly
to .vrmesh files.

Installation
============

Copy the .mp file for the respective Mudbox version to the "plugins" folder
inside the root folder of Mudbox (f.e. "C:\Program Files\Autodesk\Mudbox 2016
Ext 1\plugins").

Usage
=====

In Mudbox, select the objects that you want to export, go to File > Export
Selection...; a dialog with the .vrmesh export options will appear. The options
are similar to .vrmesh export options in other applications like 3ds Max and
Maya.
 